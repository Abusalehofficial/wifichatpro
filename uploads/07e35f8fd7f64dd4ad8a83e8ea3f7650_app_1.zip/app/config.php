<?php
//Config Database
define('DB_HOST', 'localhost');
define('DB_USER', 'opps_opps1');
define('DB_PASS', 'd^8z6PE!@@UN');
define('DB_NAME', 'opps_opps1');
define('TIMEZONE', 'Asia/Kolkata');
define('ENCRYPTION_KEY', '61af21a3fe1690e3a0dc73bcaa1d6bda');
