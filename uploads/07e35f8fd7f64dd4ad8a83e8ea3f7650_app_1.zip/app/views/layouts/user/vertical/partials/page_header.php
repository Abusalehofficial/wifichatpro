<div class="page-header">
    <h1 class="page-title">
        <span class="fa fa-th-large"></span> <?php echo $controller_title; ?>
    </h1>
    <div class="page-options d-flex">
        <a href="<?=admin_url($controller_name . "/update")?>" class="ajaxModal btn btn-outline-primary">
        <span class="fe fe-plus"></span>
        Add new
        </a>
    </div>
</div>
