<section class="add-funds m-t-50">   
  <div class="container-fluid">
    <div class="row justify-content-md-center">
      <div class="col-md-5">
        <div class="card">
          <div class="card-header d-flex align-items-center">
            <h3 class="m-t-10 text-danger"><i class="fe fe-alert-triangle "></i> <?=lang("payment_unsucessfully")?></h3>
          </div>
          <div class="card-body">
          	<div class="detail text-center text-danger">
	            <p class="p-t-20"><?=lang("sorry_your_payment_failed_no_charges_were_made")?></p>
          	</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

